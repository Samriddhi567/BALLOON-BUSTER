var backGround,backGroundImage,blue_balloon,blue_balloonImage,pink_balloon,pink_balloonImage
var green_balloon,green_balloonImage,red_balloon,red_balloonImage,bow,bow_Image
var arrow,arrow_img
var score=0
var redB,greenB,blueB,pinkB

function preload(){  
 //load your images here 
     backGroundImage = loadImage("background0.png");
      blue_balloonImage=loadImage("blue_balloon0.png");
      pink_balloonImage=loadImage("pink_balloon0.png");
      green_balloonImage=loadImage("green_balloon0.png");
      red_balloonImage=loadImage("red_balloon0.png");
      bow_Image=loadImage("bow0.png");
      arrow_Image=loadImage("arrow0.png");
}


function setup() {
  createCanvas(600, 600);
  
  //add code here
  backGround = createSprite(200,180,400,20);
  backGround.addImage("background0.png",backGroundImage);
    backGround.x = backGround.width /2;
    backGround.velocityX = -4;
    backGround.scale=2.5
  
  redB= new Group();
    greenB= new Group();
    blueB= new Group();
     pinkB= new Group();   
  arrowGroup=new Group();
  
  
  bow=createSprite(500,300,10,10);
  bow.addImage(bow_Image);
}
  
function red_balloon() {
  var red = createSprite(0,Math.round(random(20, 370)), 10, 10);
  red.addImage(red_balloonImage);
  red.velocityX = 3;
  red.lifetime = 150;
  red.scale = 0.1;
  red.liftime=150;
  redB.add(red);
}

function blue_balloon() {
  var blue = createSprite(0,Math.round(random(20, 370)), 10, 10);
  blue.addImage(blue_balloonImage);
  blue.velocityX = 3;
  blue.lifetime = 150;
  blue.scale = 0.1;
  blue.liftime=150;
  blueB.add(blue);
}

function green_balloon() {
 var green = createSprite(0,Math.round(random(20, 370)), 10, 10);
  green.addImage(green_balloonImage);
  green.velocityX = 3;
  green.lifetime = 150;
  green.scale = 0.1;
 green.liftime=150;
    greenB.add(green);

}

function pink_balloon() {
  pink = createSprite(0,Math.round(random(20, 370)), 10, 10);
  pink.addImage(pink_balloonImage);
  pink.velocityX = 3;
  pink.scale = 1;
   pink.liftime=150;
    pinkB.add(pink);
}

function draw() {
 
    if(backGround.x<0){
       backGround.x = backGround.width /2;
    }
      bow.y=mouseY;

      if (keyDown("space")) {
        createArrow();
      }
  
  if(arrowGroup.isTouching(redB)){
    redB.destroyEach();
    arrowGroup.destroyEach();
    score=score+1;
  }

    
  if(arrowGroup.isTouching(greenB)){
    greenB.destroyEach();
    arrowGroup.destroyEach();
    score=score+1;
  }

    
  if(arrowGroup.isTouching(pinkB)){
    pinkB.destroyEach();
    arrowGroup.destroyEach();
    score=score+2;
  }

    
  if(arrowGroup.isTouching(blueB)){
    blueB.destroyEach();
    arrowGroup.destroyEach();
    score=score+3;
  }

   var select_balloon=Math.round(random(1,4));
  console.log(select_balloon)
  if(World.frameCount % 80==0){
    if(select_balloon==2){
      pink_balloon();
    }
    else if(select_balloon==1){
      blue_balloon();
    }
     else if(select_balloon==3){
      green_balloon();
    }
     else if(select_balloon==4){
      red_balloon();
    }
  }
  
  drawSprites();
  text("Score:"+score,270,30);
  
}


function createArrow() {
    arrow = createSprite(360, 100, 10, 20);
    arrow.scale = 0.3;
    arrow.velocityX = -4;
    arrow.addImage(arrow_Image);
    arrow.y = bow.y;
  arrow.liftime=150;
     arrowGroup.add(arrow);
}
  

